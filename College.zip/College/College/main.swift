//
//  main.swift
//  College
//
//  Created by MacStudent on 2017-10-13.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation

var college = College(college_code: [1], college_name: ["Lambton College"])
var department = Department(dept_id: [11,12,13], dept_name: ["IT","Mech","Elec"], head_of_dept: ["Marcos Bittencourt"])
var Class = classroom(class_id: [121], inst_id: [1211], class_start_time: ["8:30"], class_end_time: ["3:30"])
var instructor = Instructor(inst_id: [1211], inst_name: ["Marcos Bittencourt"], no_of_times_hod: [10])
var student = Student(stud_id: [710899], stud_name: ["Chirag"])
var course = Course(course_id: [12121], course_name: ["Mobile Application"])
var grade = grades(assignment_marks: [90.00], project_marks: [85.00], Test_marks: [95.00])
func InstuctorPerDepartment()
{
    for i in department.dept_id
    {
        var InsPerDep : Int = 0
        for j in instructor.dept_id
        {
            if (j == i)
            {
                InsPerDep = InsPerDep + 1
            }
            else
            {
                print("No Instructor in Department")
            }
        }
        print("Department ID : \(i), Instructor Per Department : \(InsPerDep)")
    }
}
//InstuctorPerDepartment()
func GradesPerStudent()
{
    for i in grade.stud_id
    {
        for j in student.stud_id
        {
            if (j == i)
            {
                print("Student ID : \(i)")
                for j in student.stud_name
                {
                    print("Student Name : \(j)")
                    break
                }
                for j in grade.assignment_marks
                {
                    print("Assignment Marks : \(j)")
                    break
                }
            }
        }
    }
}
//GradesPerStudent()
func Instructor_Details()
{
    for i in instructor.inst_id
    {
        print("Instructor ID : \(i)")
        for i in instructor.inst_name
        {
            print("Instructor Name : \(i)")
            for i in instructor.no_of_times_hod
            {
                print("Number Of Times HOD : \(i)")
                break
            }
            break
        }
    }
}
//Instructor_Details()
func Student_Details()
{
    for i in student.stud_id
    {
        print("Student ID : \(i)")
        for i in student.stud_name
        {
            print("Student Name : \(i)")
            break
        }
        for i in course.course_id
        {
            print("Course ID : \(i)")
            break
        }
        for i in course.course_name
        {
            print("Course Name : \(i)")
            break
        }
        for i in department.dept_name
        {
            print("Department Name : \(i)")
            break
        }
    }
}
//Student_Details()
func Head_Of_Department()
{
    for i in department.head_of_dept
    {
        print("Head Of Department : \(i)")
        for i in instructor.no_of_times_hod
        {
            print("Number Of HOD : \(i)")
            break
        }
    }
}
//Head_Of_Department()
