//
//  College.swift
//  College
//
//  Created by MacStudent on 2017-10-13.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation
class College
{
    var college_code : [Int]
    var college_name : [String]
    init(college_code :[Int],college_name :[String])
    {
        self.college_name = college_name
        self.college_code = college_code
    }
    func getColCode() -> [Int]
    {
        return college_code
    }
    func getColName() -> [String]
    {
        return college_name
    }
    func setColCode(_ college_code:[Int])
    {
        self.college_code = college_code
    }
    func setColName(_ college_name:[String])
    {
        self.college_name = college_name
    }
}

class Department : College
{
    var dept_id : [Int]
    var dept_name : [String]
    var head_of_dept : [String]
    init(dept_id : [Int],dept_name : [String],head_of_dept : [String])
    {
        self.dept_id = dept_id
        self.dept_name = dept_name
        self.head_of_dept = head_of_dept
        super.init(college_code: [1212], college_name: ["LAMBTON COLLEGE"])
    }
    func getDept_id() -> [Int]
    {
        return dept_id
    }
    func getDept_name() -> [String]
    {
        return dept_name
    }
    func getHead_of_dept() -> [String]
    {
        return head_of_dept
    }
    func setDept_id(_ dept_id:[Int])
    {
        self.dept_id = dept_id
    }
    func setDept_name(_ dept_name:[String])
    {
        self.dept_name = dept_name
    }
    func setHead_of_dept(_ head_of_dept:[String])
    {
        self.head_of_dept = head_of_dept
    }
}

class classroom : Instructor
{
    var class_id : [Int]
    var class_start_time : [String]
    var class_end_time : [String]
    init(class_id : [Int],inst_id : [Int],class_start_time : [String],class_end_time : [String])
    {
        self.class_id = class_id
        self.class_start_time = class_start_time
        self.class_end_time = class_end_time
        super.init(inst_id: [121], inst_name: ["Chirag"], no_of_times_hod: [10])
    }
    func getClass_id() -> [Int]
    {
        return class_id
    }
    func getClass_start_time() -> [String]
    {
        return class_start_time
    }
    func getClass_end_time() -> [String]
    {
        return class_end_time
    }
    func setClass_id(_ class_id :[Int])
    {
        self.class_id = class_id
    }
    func setClass_Start_time(_ class_start_time : [String])
    {
        self.class_start_time = class_start_time
    }
    func setClass_end_time(_ class_end_time : [String])
    {
        self.class_end_time = class_end_time
    }
}

class Student : Course
{
    var stud_id : [Int]
    var stud_name : [String]
    init(stud_id : [Int],stud_name : [String])
    {
        self.stud_id = stud_id
        self.stud_name = stud_name
        super.init(course_id: [11], course_name: ["Mobile Application Design and Development"])
    }
    func getStud_id() -> [Int]
    {
        return stud_id
    }
    func getStud_name() -> [String]
    {
        return stud_name
    }
    func setStud_id(_ stud_id : [Int])
    {
       self.stud_id = stud_id
    }
    func setstud_name(_ stud_name : [String])
    {
        self.stud_name = stud_name
    }
}

class Instructor : Course
{
    var inst_id : [Int]
    var inst_name : [String]
    var no_of_times_hod : [Int]
    init(inst_id : [Int],inst_name : [String],no_of_times_hod : [Int])
    {
        self.inst_id = inst_id
        self.inst_name = inst_name
        self.no_of_times_hod = no_of_times_hod
        super.init(course_id: [12], course_name: ["Database Management System"])
    }
    func getInst_id() -> [Int]
    {
        return inst_id
    }
    func getInst_name() -> [String]
    {
        return inst_name
    }
    func getNo_of_times_hod() -> [Int]
    {
        return no_of_times_hod
    }
    
    func setInst_id(_ inst_id : [Int])
    {
        self.inst_id = inst_id
    }
    func setInst_name(_ inst_name : [String])
    {
      self.inst_name = inst_name
    }
    func setNo_of_times_hod(_ no_of_times_hod : [Int])
    {
        self.no_of_times_hod = no_of_times_hod
    }
}
class Course : Department
{
    var course_id : [Int]
    var course_name : [String]
    init(course_id : [Int],course_name :[String])
    {
        self.course_id = course_id
        self.course_name = course_name
        super.init(dept_id: [1], dept_name: ["IT"], head_of_dept: ["Marcos Bittencourt"])
    }
    func getCourse_id() -> [Int]
    {
        return course_id
    }
    func getCourse_name() -> [String]
    {
        return course_name
    }
    func setCourse_id(_ course_id : [Int])
    {
        self.course_id = course_id
    }
    func setCourse_name(_ course_name : [String])
    {
        self.course_name = course_name
    }
}
class grades : Student
{
    var assignment_marks : [Double]
    var project_marks : [Double]
    var Test_marks : [Double]
    init(assignment_marks : [Double],project_marks :[Double],Test_marks :[Double])
    {
        self.assignment_marks = assignment_marks
        self.project_marks = project_marks
        self.Test_marks = Test_marks
        super.init(stud_id: [710899], stud_name: ["CHIRAG"])
    }
    func getAssignment_Marks () -> [Double]
    {
        return assignment_marks
    }
    func getProject_marks() -> [Double]
    {
        return project_marks
    }
    func getTest_marks() -> [Double]
    {
        return Test_marks
    }
    func setAssignment_marks(_ assignment_marks :[Double])
    {
        self.assignment_marks = assignment_marks
    }
    func setProject_marks(_ project_marks :[Double])
    {
        self.project_marks = project_marks
    }
    func setTest_marks(_ Test_marks: [Double])
    {
        self.Test_marks = Test_marks
    }
}
